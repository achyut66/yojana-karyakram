<?php
require_once("includes/initialize.php");
$res= array();
$topic_area_id = $_POST['topic_area_id'];
$topic_area_type_id = $_POST['topic_area_type_id'];
